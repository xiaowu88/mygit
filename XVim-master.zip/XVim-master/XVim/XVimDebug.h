//
//  XVimDebug.h
//  XVim
//
//  Created by Suzuki Shuichiro on 2/16/13.
//
//

#import <Foundation/Foundation.h>

@interface XVimDebug : NSObject

@end
