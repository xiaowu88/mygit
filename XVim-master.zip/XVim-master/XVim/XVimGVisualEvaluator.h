//
//  XVimGVisualEvaluator.h
//  XVim
//
//  Created by Tomas Lundell on 14/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "XVimGMotionEvaluator.h"

@interface XVimGVisualEvaluator : XVimGMotionEvaluator

@end
