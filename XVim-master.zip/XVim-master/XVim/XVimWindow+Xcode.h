//
//  XVimWindow+Xcode.h
//  XVim
//
//  Created by Suzuki Shuichiro on 9/18/12.
//
//

#import "XVimWindow.h"

@interface XVimWindow (Xcode)

@end
