//
//  XVimWindowEvaluator.h
//  XVim
//
//  Created by Nader Akoury 4/14/12
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "XVimArgumentEvaluator.h"

@interface XVimWindowEvaluator : XVimEvaluator

@end