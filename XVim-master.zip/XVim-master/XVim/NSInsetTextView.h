//
//  NSInsetTextView.h
//  XVim
//
//  Created by Tomas Lundell on 5/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSInsetTextView : NSTextView
@property CGSize inset;

@end
