//
//  XVimBuffer.m
//  XVim
//
//  Created by John AppleSeed on 16/11/13.
//
//

#import "XVimBuffer.h"

@implementation XVimBuffer {
}
@synthesize textStorage = _textStorage;

@end
